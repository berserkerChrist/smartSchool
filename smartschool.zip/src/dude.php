<?php

  $variable = base64_decode("Ym90Z3VhcmQtY29udGFjdEBnb29nbGUuY29t");

  echo $variable;

?>
